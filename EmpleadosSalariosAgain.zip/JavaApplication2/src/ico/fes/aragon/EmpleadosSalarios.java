/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.aragon;
import java.util.*;

/**
 *
 * @author AG
 */
public class EmpleadosSalarios {
  //programa que muestra el nombre y el sueldo del empleado 

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         //creamos los arrays
        String[] empleados = new String[10];
        double[] sueldos = new double[10];
        double[] dias= new double[10];
        double[] horasE= new double[10];
        double[] precio=new double [10];
        double[] sueldoFinal=new double [10];

        //variables donde guardar el nombre y sueldo del empleado 
        String nombreMayor;
        double mayorSueldo;

        int i = 0;

        //se lee el primer empleado
        System.out.println("Lectura de nombres y sueldos de empleados: ");
        System.out.print("Empleado " + (i + 1) + ": ");
        empleados[i] = sc.nextLine();
        System.out.print("Sueldo por dia: ");
        sueldos[i] = sc.nextDouble();
        System.out.println("Dias trabajados: ");
        dias[i]= sc.nextDouble();
        System.out.println("Horas extra trabajadas");
        horasE[i]= sc.nextDouble();
        
       precio[i]= horasE[i] * 85;
       sueldoFinal[i] = dias[i] * sueldos[i];
       sueldoFinal[i] = sueldoFinal[i] +precio[i];
       
        System.out.println("El sueldo final es" + sueldoFinal[i]);
          
        
       
        double masHoras = horasE[i];
        nombreMayor = empleados[i];

       
        for (i = 1; i < empleados.length; i++) {
            sc.nextLine(); //limpiar el buffer
            System.out.print("Empleado " + (i + 1) + ": ");
            empleados[i] = sc.nextLine();
            System.out.print("Horas extra: ");
            sueldos[i] = sc.nextDouble();
            
            if (horasE[i] > masHoras) {
                masHoras = horasE[i];
                nombreMayor = empleados[i];
                
                
            }
        }
        
        double menosDias = dias[i];
        String nombreMenor = empleados[i];

       
        for (i = 1; i < empleados.length; i++) {
            sc.nextLine(); //limpiar el buffer
            System.out.print("Empleado " + (i + 1) + ": ");
            empleados[i] = sc.nextLine();
            System.out.print("Dias Trabajados: ");
            sueldos[i] = sc.nextDouble();
          
            if (dias[i] > menosDias) {
                menosDias = dias[i];
                nombreMenor = empleados[i];
                
                
            }
        }

        //mostrar resultados
        System.out.println("Empleado con menos dias trabajados: " + nombreMenor );
        System.out.println("Dias trabajados: " + menosDias);
    }

}