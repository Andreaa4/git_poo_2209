/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.poo.abstractas;

/**
 *
 * @author Pc
 */
public class Piano extends Instrumento {
   private int numeroTeclas;

    public Piano(int numeroTeclas) {
        this.numeroTeclas = numeroTeclas;
    }

    public Piano(int numeroTeclas, int anioConstruccion, String marca) {
        super(anioConstruccion, marca);
        this.numeroTeclas = numeroTeclas;
    }

    public int getNumeroTeclas() {
        return numeroTeclas;
    }

    public void setNumeroTeclas(int numeroTeclas) {
        this.numeroTeclas = numeroTeclas;
    }

    @Override
    public void afinar() {
        System.out.println("Pisar el pedal"); 
        System.out.println("Afinar cuerdas centrales");
        System.out.println("Tocar nota y comprobar su tono");
        System.out.println("Afinar de esta manera todas las notas de la octava");
        
    }

    @Override
    public void tocar() {
        System.out.println("Tin...Tin...TAN"); 
    }
   
}
