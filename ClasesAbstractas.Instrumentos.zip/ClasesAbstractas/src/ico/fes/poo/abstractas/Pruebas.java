/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.poo.abstractas;
/**
 *
 * @author Pc
 */
public class Pruebas {
    public static void main (String[] args){
        Guitarra g=new Guitarra(6, 1967, "Gibson");
        
       System.out.println(g.getAnioConstruccion());
       System.out.println(g.getMarca());
       g. afinar();
       g.tocar();
       
       
       
        Flauta f=new Flauta(8, 2004, "Yamaha");
        
       System.out.println(f.getAnioConstruccion());
       System.out.println(g.getMarca());
       f. afinar();
       f.tocar();
          
       
       
        Piano p=new Piano(88, 1900, "Schimmel");
        
       System.out.println(p.getAnioConstruccion());
       System.out.println(g.getMarca());
       p. afinar();
       p.tocar();
    }
       
  
    
}
