/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.poo.abstractas;

/**
 *
 * @author Pc
 */
public class Flauta extends Instrumento {
   private int numeroOrificios;

    public Flauta(int numeroOrificios) {
        this.numeroOrificios = numeroOrificios;
    }

    public Flauta(int numeroOrificios, int anioConstruccion, String marca) {
        super(anioConstruccion, marca);
        this.numeroOrificios = numeroOrificios;
    }

    public int getNumeroOrificios() {
        return numeroOrificios;
    }

    public void setNumeroOrificios(int numeroOrificios) {
        this.numeroOrificios = numeroOrificios;
    }

    @Override
    public void afinar() {
        System.out.println("Colocar la embocadura"); 
        System.out.println("Chequear la posicion del corcho de la embocadura");
        System.out.println("Ajustar hasta que suene armonico");
        
    }

    @Override
    public void tocar() {
        System.out.println("Fiu...Fiu...fiufiu"); 
    }
   
}