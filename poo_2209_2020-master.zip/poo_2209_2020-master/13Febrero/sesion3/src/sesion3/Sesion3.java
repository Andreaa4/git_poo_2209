/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sesion3;

import ico.fes.poo.Reloj;

/**
 *
 * @author LABCOM2
 */
public class Sesion3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Reloj wacho=new Reloj(12, 37, 44);
        wacho.mostrarHora();
    }
    
}
