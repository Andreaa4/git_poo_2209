/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel;

import java.util.Scanner;

/**
 *
 * @author Pc
 */
public class Hotel {

    int tipoH, dias, tipoV;
    float habitacion, vista, total;
    String preguntaH, preguntaV;
    Scanner lector = new Scanner(System.in);

    public void preguntarDatos() {
        System.out.println("¿Desea una habitacion con servicio incluido?");
        preguntaH = lector.nextLine();
        if (preguntaH.equals("no") || preguntaH.equals("No") || preguntaH.equals("NO")) {
            System.out.println("BIENVENIDO");
            System.out.println("¿Que tipo de habitacion desea?");
            System.out.println("1.- Sencilla        $1600");
            System.out.println("2.- Matrimonial     $2650");
            System.out.println("3.- Suite           $4890");
            System.out.println("4.- King            $6250");
            System.out.println("5.- Precidencial    $8100");
            tipoH = lector.nextInt();
            if (tipoH == 1) {
                habitacion = 1600f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    tipoV = lector.nextInt();
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 2) {
                habitacion = 2650f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 3) {
                habitacion = 4890f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 4) {
                habitacion = 6250f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 5) {
                habitacion = 8100f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            }

        } else if (preguntaH.equals("Si") || preguntaH.equals("si") || preguntaH.equals("SI")) {
            System.out.println("BIENVENIDO");
            System.out.println("¿Que tipo de habitacion desea?");
            System.out.println("1.- Sencilla        $2200");
            System.out.println("2.- Matrimonial     $3650");
            System.out.println("3.- Suite           $5950");
            System.out.println("4.- King            $7850");
            System.out.println("5.- Precidencial    $9950");
            tipoH = lector.nextInt();
            if (tipoH == 1) {
                habitacion = 2200f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    tipoV = lector.nextInt();
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 2) {
                habitacion = 3650f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 3) {
                habitacion = 5950f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 4) {
                habitacion = 7850f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            } else if (tipoH == 5) {
                habitacion = 9950f;
                System.out.println("¿Cuantos dias desea hospedarse?");
                dias = lector.nextInt();
                System.out.println("¿Desea agregar algun tipo de vista?");
                preguntaV = lector.next();
                if (preguntaV.equals("si") || preguntaV.equals("Si") || preguntaV.equals("Si")) {
                    System.out.println("Que vista desea?");
                    System.out.println("1.- Vista al mar                $350");
                    System.out.println("2.- Vistal al campo de golf     $200");
                    if (tipoV == 1) {
                        vista = 350f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    } else {
                        vista = 2000f;
                        total = habitacion * dias;
                        total = total + vista;
                        System.out.println("Tu total es: " + total);
                    }
                } else if (preguntaV.equals("no") || preguntaV.equals("No") || preguntaV.equals("No")) {

                }
            }
        } else {
            System.out.println("Datos ingresado no valido");
        }
    }

    public static void main(String[] args) {
        Hotel h = new Hotel();
        h.preguntarDatos();
    }
}
